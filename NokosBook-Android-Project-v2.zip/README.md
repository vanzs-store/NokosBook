NokosBook v1.1

Fitur: dashboard filter Hari ini/Kemarin/Pilih tanggal; modal dihitung berdasarkan tanggal beli; pemasukan berdasarkan tanggal jual walaupun stok dibeli di periode lain; keuntungan = pemasukan periode dikurangi modal periode; riwayat dikelompokkan berdasarkan tanggal pembelian dan menampilkan tanggal jual terpisah; tambah/edit stok, status otomatis SOLD saat harga jual diisi, salin nomor stok.

Build: upload seluruh isi ZIP ke root repository GitHub branch main. Buka Actions > Build NokosBook APK > Run workflow. Unduh artifact NokosBook-APK setelah build selesai.

Catatan: versi ini menyimpan data secara lokal di perangkat. Login Google dan sinkronisasi cloud belum diimplementasikan.
